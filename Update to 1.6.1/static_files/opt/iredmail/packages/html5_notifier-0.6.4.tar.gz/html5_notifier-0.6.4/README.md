![ScreenShot](/screenshot.png)

HTML5_Notifier is a Roundcube plugin.

It displays Desktop Notifications like the ones you might know from Google Mail. Just keep Roundcube opened in a (minimized) tab and enjoy getting notifications every time a new mail arrives.

It just works in modern browsers like Google Chrome, SRWare Iron or Firefox, because "Desktop Notification" is a new feature in HTML5.

